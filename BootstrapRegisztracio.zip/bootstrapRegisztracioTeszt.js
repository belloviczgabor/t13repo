function LegkulsoDivElemEllenorzes() {
    let tesztElem = document.querySelector("div");
    if (tesztElem.class = "container") {
        console.log("Sikeres 01. teszt");
    }
    else {
        console.log("Sikertelen 01. teszt");
    }
}
LegkulsoDivElemEllenorzes()

function CimsorTartalomTeszt() {
    let tesztElem = document.querySelector("h1").innerHTML;
    if (tesztElem == "Tanfolyam regisztráció") {
        console.log("Sikeres 02. teszt");
    }
    else {
        console.log("Sikertelen 02. teszt")
    }
}
CimsorTartalomTeszt()

function ElsoInputMezoTipusa() {
    let tesztElem = document.querySelector("input");
    if (tesztElem.type == "text") {
        console.log("Sikeres 03. teszt");
    }
    else {
        console.log("Sikertelen 03. teszt")
    }
}
ElsoInputMezoTipusa()

function ElsoInputMezoAzonositoja() {
    let tesztElem = document.querySelector("input");
    if (tesztElem.id == "veznev") {
        console.log("Sikeres 04. teszt");
    }
    else {
        console.log("Sikertelen 04. teszt")
    }
}
ElsoInputMezoAzonositoja()

function ElsoInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelector("input");
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 05. teszt");
    }
    else {
        console.log("Sikertelen 05. teszt")
    }
}
ElsoInputMezoBootstrapOsztalya()

function MasodikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[1];
    if (tesztElem.type = "text") {
        console.log("Sikeres 06. teszt");
    }
    else {
        console.log("Sikertelen 06. teszt")
    }
}
MasodikInputMezoTipusa()

function MasodikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[1];
    if (tesztElem.id == "kernev") {
        console.log("Sikeres 07. teszt");
    }
    else {
        console.log("Sikertelen 07. teszt")
    }
}
MasodikInputMezoAzonositoja()

function MasodikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[1];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 08. teszt");
    }
    else {
        console.log("Sikertelen 08. teszt")
    }
}
MasodikInputMezoBootstrapOsztalya()

function HarmadikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[2];
    if (tesztElem.type = "text") {
        console.log("Sikeres 09. teszt");
    }
    else {
        console.log("Sikertelen 09. teszt")
    }
}
HarmadikInputMezoTipusa()

function HarmadikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[2];
    if (tesztElem.id == "fnev") {
        console.log("Sikeres 10. teszt");
    }
    else {
        console.log("Sikertelen 10. teszt")
    }
}
HarmadikInputMezoAzonositoja()

function HarmadikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[2];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 11. teszt");
    }
    else {
        console.log("Sikertelen 11. teszt")
    }
}
HarmadikInputMezoBootstrapOsztalya()

function NegyedikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[3];
    if (tesztElem.type = "password") {
        console.log("Sikeres 12. teszt");
    }
    else {
        console.log("Sikertelen 12. teszt")
    }
}
NegyedikInputMezoTipusa()

function NegyedikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[3];
    if (tesztElem.id == "pass1") {
        console.log("Sikeres 13. teszt");
    }
    else {
        console.log("Sikertelen 13. teszt")
    }
}
NegyedikInputMezoAzonositoja()

function NegyedikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[3];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 14. teszt");
    }
    else {
        console.log("Sikertelen 14. teszt")
    }
}
NegyedikInputMezoBootstrapOsztalya()

function OtodikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[4];
    if (tesztElem.type = "password") {
        console.log("Sikeres 15. teszt");
    }
    else {
        console.log("Sikertelen 15. teszt")
    }
}
OtodikInputMezoTipusa()

function OtodikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[4];
    if (tesztElem.id == "pass2") {
        console.log("Sikeres 16. teszt");
    }
    else {
        console.log("Sikertelen 16. teszt")
    }
}
OtodikInputMezoAzonositoja()

function OtodikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[4];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 17. teszt");
    }
    else {
        console.log("Sikertelen 17. teszt")
    }
}
OtodikInputMezoBootstrapOsztalya()

function HatodikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[5];
    if (tesztElem.type = "email") {
        console.log("Sikeres 18. teszt");
    }
    else {
        console.log("Sikertelen 18. teszt")
    }
}
HatodikInputMezoTipusa()

function HatodikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[5];
    if (tesztElem.id == "email") {
        console.log("Sikeres 19. teszt");
    }
    else {
        console.log("Sikertelen 19. teszt")
    }
}
HatodikInputMezoAzonositoja()

function HatodikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[5];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 20. teszt");
    }
    else {
        console.log("Sikertelen 20. teszt")
    }
}
HatodikInputMezoBootstrapOsztalya()

function HetedikInputMezoTipusa() {
    let tesztElem = document.querySelectorAll("input")[6];
    if (tesztElem.type = "tel") {
        console.log("Sikeres 21. teszt");
    }
    else {
        console.log("Sikertelen 21. teszt")
    }
}
HetedikInputMezoTipusa()

function HetedikInputMezoAzonositoja() {
    let tesztElem = document.querySelectorAll("input")[6];
    if (tesztElem.id == "tel") {
        console.log("Sikeres 22. teszt");
    }
    else {
        console.log("Sikertelen 22. teszt")
    }
}
HetedikInputMezoAzonositoja()

function HetedikInputMezoBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")[6];
    if (tesztElem.class = "form-control") {
        console.log("Sikeres 23. teszt");
    }
    else {
        console.log("Sikertelen 23. teszt")
    }
}
HetedikInputMezoBootstrapOsztalya()



function FelhasznaloNevAlattiUzenetOsztalyai() {
    let tesztElem = document.querySelector("small");
    if (tesztElem.class = "form-text text-muted") {
        console.log("Sikeres 26. teszt");
    }
    else {
        console.log("Sikertelen 26. teszt")
    }
}
FelhasznaloNevAlattiUzenetOsztalyai()

function FelhasznaloNevAlattiUzenetTartalma() {
    let tesztElem = document.querySelector("small").innerHTML;
    if (tesztElem == "Beceneve, mely mások számára is látható.") {
        console.log("Sikeres 27. teszt");
    }
    else {
        console.log("Sikertelen 27. teszt")
    }
}
FelhasznaloNevAlattiUzenetTartalma()

function EmailMezoAlattiUzenetOsztalyai() {
    let tesztElem = document.querySelectorAll("small")[1];
    if (tesztElem.class = "form-text text-muted") {
        console.log("Sikeres 28. teszt");
    }
    else {
        console.log("Sikertelen 28. teszt")
    }
}
EmailMezoAlattiUzenetOsztalyai()

function EmailMezoAlattiUzenetTartalma() {
    let tesztElem = document.querySelectorAll("small")[1].innerHTML;
    if (tesztElem = "Ide továbbítjuk a legfontosabb tanfolyam információkat önnek.") {
        console.log("Sikeres 29. teszt");
    }
    else {
        console.log("Sikertelen 29. teszt")
    }
}
EmailMezoAlattiUzenetTartalma()

function TelefonMezoAlattiUzenetOsztalyai() {
    let tesztElem = document.querySelectorAll("small")[2];
    if (tesztElem.class = "form-text text-muted") {
        console.log("Sikeres 30. teszt");
    }
    else {
        console.log("Sikertelen 30. teszt")
    }
}
TelefonMezoAlattiUzenetOsztalyai()

function TelefonMezoAlattiUzenetTartalma() {
    let tesztElem = document.querySelectorAll("small")[2].innerHTML;
    if (tesztElem == "Ha szeretne akár azonnal értesülni a fontosabb hírekről") {
        console.log("Sikeres 31. teszt");
    }
    else {
        console.log("Sikertelen 31. teszt")
    }
}
TelefonMezoAlattiUzenetTartalma()

function GombAlapertelmezettBootsrapOsztalya() {
    let tesztElem = document.querySelectorAll("button");
    if (tesztElem.class = "btn w-100") {
        console.log("Sikeres 33. teszt");
    }
    else {
        console.log("Sikertelen 33. teszt")
    }
}
GombAlapertelmezettBootsrapOsztalya()

function GombSzine() {
    let tesztElem = document.querySelectorAll("button");
    if (tesztElem.class = "btn-primary") {
        console.log("Sikeres 34. teszt");
    }
    else {
        console.log("Sikertelen 34. teszt")
    }
}
GombSzine()

function GombMerete() {
    let tesztElem = document.querySelector("button");
    if (tesztElem.class = "w-100") {
        console.log("Sikeres 35. teszt");
    }
    else {
        console.log("Sikertelen 35. teszt")
    }
}
GombMerete()

function GombFelirata() {
    let tesztElem = document.querySelector("button").innerHTML;
    if (tesztElem == "Regisztrálok") {
        console.log("Sikeres 36. teszt");
    }
    else {
        console.log("Sikertelen 36. teszt")
    }
}
GombFelirata()

function SelectMezoElemekSzama() {
    let tesztElem = document.querySelectorAll("#tipus option");
    if (tesztElem.length == 4) {
        console.log("Sikeres 37. teszt");
    }
    else {
        console.log("Sikertelen 37. teszt");
    }
}
SelectMezoElemekSzama()

function SelectMezoKivalasztottElemErteke() {
    let tesztElem = document.querySelectorAll("#tipus option").innerHTML;
    if (tesztElem = "Webfejlesztő" && "Junior frontend fejlesztő" && "MySQL intenzív tanfolyam" && "C# alapismeretek") {
        console.log("Sikeres 38. teszt");
    }
    else {
        console.log("Sikertelen 38. teszt")
    }
}
SelectMezoKivalasztottElemErteke()





