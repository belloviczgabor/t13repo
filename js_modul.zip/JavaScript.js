function KockaTerfogat(a) {
    let terfogat = a * a * a
    return terfogat
}
document.write(KockaTerfogat(4))

// 2.feladat
function SzovegVisszafele(szoveg) {
    let forditottSzoveg = ""
    for (let i = szoveg.length - 1; i >= 0; i--) {
        forditottSzoveg += szoveg[i];
    }
    return forditottSzoveg;
}
document.write("<hr>")
document.write(SzovegVisszafele("Buba"))
//3.feladat

function CegAtlagEletkor(Dolgozok) {
    let eletkor = 0;
    for (let i = 0; i < Dolgozok.length; i++) {
        eletkor += Dolgozok[i].kor;
    }
    return eletkor / Dolgozok.length;
}
document.write("<hr>");
document.write(Math.round(CegAtlagEletkor(Dolgozok)));
