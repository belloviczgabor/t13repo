//1.feladat
function LegkulsoDivElemEllenorzes() {
    let tesztElem = document.querySelector("div");
    if (tesztElem.class = "p-3") {
        console.log("Sikeres 1. teszt");
    }
    else {
        console.log("Sikertelen 1. teszt");
    }
}
LegkulsoDivElemEllenorzes()

function CimsorTartalomTeszt1() {
    let tesztElem = document.querySelector("h3").innerHTML;
    if (tesztElem == "Hány képviselőjelölt indult a helyhatósági választáson?") {
        console.log("Sikeres 2. teszt");
    }
    else {
        console.log("Sikertelen 2. teszt")
    }
}
CimsorTartalomTeszt1()

function GombTipusa() {
    let tesztElem = document.querySelectorAll("button");
    if (tesztElem.type = "button") {
        console.log("Sikeres 3. teszt");
    }
    else {
        console.log("Sikertelen 3. teszt")
    }
}
GombTipusa()

function GombBootsrapOsztalya() {
    let tesztElem = document.querySelectorAll("button");
    if (tesztElem.class = "btn btn-dark w-100 my-3") {
        console.log("Sikeres 4. teszt");
    }
    else {
        console.log("Sikertelen 4. teszt")
    }
}
GombBootsrapOsztalya()

function GombFelirata() {
    let tesztElem = document.querySelector("button").innerHTML;
    if (tesztElem == "KepviselokSzama") {
        console.log("Sikeres 5. teszt");
    }
    else {
        console.log("Sikertelen 5. teszt")
    }
}
GombFelirata()

function GombFuggvenye() {
    let tesztElem = document.querySelectorAll("button");
    if (tesztElem.onclick = "KepviselokSzama()") {
        console.log("Sikeres 6. teszt");
    }
    else {
        console.log("Sikertelen 6. teszt")
    }
}
GombFuggvenye()

function BekezdesID() {
    let tesztElem = document.querySelector("p");
    if (tesztElem.id = "#feladat1Eredmeny") {
        console.log("Sikeres 7. teszt");
    }
    else {
        console.log("Sikertelen 7. teszt")
    }
}
BekezdesID()

//2.feladat
function CimsorTartalomTeszt2() {
    let tesztElem = document.querySelectorAll("h3")[1].innerHTML;
    if (tesztElem = "Készítsen egy legördülő menüt, amiben kiválaszthatunkegy pártot, vagy a független jelzőt, és a választás után lekérdezhetjük, az adott párt/függetlenként hány képviselőt indított a választáson") {
        console.log("Sikeres 8. teszt");
    }
    else {
        console.log("Sikertelen 8. teszt")
    }
}
CimsorTartalomTeszt2()

function GombID() {
    let tesztElem = document.querySelector("select");
    if (tesztElem.id = "PartKepviseloSelect") {
        console.log("Sikeres 9. teszt");
    }
    else {
        console.log("Sikertelen 9. teszt")
    }
}
GombID()


function GombFuggvenye2() {
    let tesztElem = document.querySelectorAll("select");
    if (tesztElem.onchange = "PartKepviselok()") {
        console.log("Sikeres 10. teszt");
    }
    else {
        console.log("Sikertelen 10. teszt")
    }
}
GombFuggvenye2()

function LegorduloListaHossz() {
    let tesztElem = document.querySelectorAll("select option");
    if (tesztElem.length == 6) {
        console.log("Sikeres 11. teszt");
    }
    else {
        console.log("Sikertelen 11. teszt")
    }
}
LegorduloListaHossz()


//3.feladat
function ElsoInputMezoTipusa() {
    let tesztElem = document.querySelector("input");
    if (tesztElem.type == "text") {
        console.log("Sikeres 14. teszt");
    }
    else {
        console.log("Sikertelen 14. teszt")
    }
}
ElsoInputMezoTipusa()

function ElsoInputMezoAzonositoja() {
    let tesztElem = document.querySelector("input");
    if (tesztElem.id == "vezeteknev") {
        console.log("Sikeres 15. teszt");
    }
    else {
        console.log("Sikertelen 15. teszt")
    }
}
ElsoInputMezoAzonositoja()



