let eredmenyek = [
    "7up Joventut;Adecco Estudiantes;81;73;Palacio Mun. De Deportes De Badalona;2005-04-03",
    "7up Joventut;Breogán Lugo;97;83;Palacio Mun. De Deportes De Badalona;2004-11-21",
    "7up Joventut;C.B. Granada;85;87;Palacio Mun. De Deportes De Badalona;2004-12-04",
    "7up Joventut;Caja San Fernando;81;99;Palacio Mun. De Deportes De Badalona;2005-01-08",
    "7up Joventut;Casademont Girona;101;79;Palacio Mun. De Deportes De Badalona;2005-01-23",
    "7up Joventut;Etosa Alicante;81;78;Palacio Mun. De Deportes De Badalona;2005-04-24",
    "7up Joventut;Forum Valladolid;95;83;Palacio Mun. De Deportes De Badalona;2004-11-06",
    "7up Joventut;Gran Canaria;73;68;Palacio Mun. De Deportes De Badalona;2005-03-13",
    "7up Joventut;Lagun Aro Bilbao Basket;76;84;Palacio Mun. De Deportes De Badalona;2004-10-06",
    "7up Joventut;Pamesa Valencia;78;85;Palacio Mun. De Deportes De Badalona;2004-10-17",
    "7up Joventut;Plus Pujol Lleida;91;67;Palacio Mun. De Deportes De Badalona;2005-02-27",
    "7up Joventut;Real Madrid;78;68;Palacio Mun. De Deportes De Badalona;2005-05-10",
    "7up Joventut;Real Madrid;79;66;Palacio Mun. De Deportes De Badalona;2005-05-22",
    "7up Joventut;Real Madrid;72;81;Palacio Mun. De Deportes De Badalona;2005-05-29",
    "7up Joventut;Ricoh Manresa;87;75;Palacio Mun. De Deportes De Badalona;2005-02-05",
    "7up Joventut;Tau Cerámica;95;92;Palacio Mun. De Deportes De Badalona;2005-03-27",
    "7up Joventut;Unelco Tenerife;90;65;Palacio Mun. De Deportes De Badalona;2004-10-27",
    "7up Joventut;Unicaja;87;89;Palacio Mun. De Deportes De Badalona;2005-04-16",
    "7up Joventut;Winterthur F.C. Barcelona;81;73;Palacio Mun. De Deportes De Badalona;2004-12-19",
    "Adecco Estudiantes;7up Joventut;87;82;Palacio Vistalegre;2004-11-28",
    "Adecco Estudiantes;Breogán Lugo;82;95;Palacio Vistalegre;2005-04-17",
    "Adecco Estudiantes;C.B. Granada;77;61;Palacio Vistalegre;2004-11-20",
    "Adecco Estudiantes;Caja San Fernando;88;80;Palacio Vistalegre;2005-05-11",
    "Adecco Estudiantes;Casademont Girona;109;73;Palacio Vistalegre;2005-04-24",
    "Adecco Estudiantes;Etosa Alicante;68;85;Palacio Vistalegre;2004-10-06",
    "Adecco Estudiantes;Forum Valladolid;91;82;Palacio Vistalegre;2005-04-09",
    "Adecco Estudiantes;Gran Canaria;68;66;Palacio Vistalegre;2005-03-27",
    "Adecco Estudiantes;Lagun Aro Bilbao Basket;99;88;Palacio Vistalegre;2005-02-06",
    "Adecco Estudiantes;Pamesa Valencia;104;106;Palacio Vistalegre;2005-01-23",
    "Adecco Estudiantes;Plus Pujol Lleida;88;85;Palacio Vistalegre;2004-12-19",
    "Adecco Estudiantes;Real Madrid;84;85;Palacio Vistalegre;2005-06-08",
    "Adecco Estudiantes;Real Madrid;68;74;Palacio Vistalegre;2005-06-10",
    "Adecco Estudiantes;Real Madrid;95;71;Palacio Vistalegre;2005-02-27",
    "Adecco Estudiantes;Ricoh Manresa;88;69;Palacio Vistalegre;2004-10-27",
    "Adecco Estudiantes;Tau Cerámica;101;86;Palacio Vistalegre;2004-11-07",
    "Adecco Estudiantes;Unelco Tenerife;83;64;Palacio Vistalegre;2005-03-12",
    "Adecco Estudiantes;Unicaja;75;83;Palacio Vistalegre;2005-01-09",
    "Adecco Estudiantes;Winterthur F.C. Barcelona;78;57;Palacio Vistalegre;2005-05-22",
    "Adecco Estudiantes;Winterthur F.C. Barcelona;81;63;Palacio Vistalegre;2005-05-29",
    "Adecco Estudiantes;Winterthur F.C. Barcelona;66;67;Palacio Vistalegre;2004-10-17",
    "Breogán Lugo;7up Joventut;80;95;Pazo Provincial Dos Deportes;2005-04-21",
    "Breogán Lugo;Adecco Estudiantes;81;89;Pazo Provincial Dos Deportes;2004-12-11",
    "Breogán Lugo;C.B. Granada;66;73;Pazo Provincial Dos Deportes;2005-05-01",
    "Breogán Lugo;Caja San Fernando;96;102;Pazo Provincial Dos Deportes;2004-10-06",
    "Breogán Lugo;Casademont Girona;96;72;Pazo Provincial Dos Deportes;2005-05-11",
    "Breogán Lugo;Etosa Alicante;77;82;Pazo Provincial Dos Deportes;2004-10-27",
    "Breogán Lugo;Forum Valladolid;105;77;Pazo Provincial Dos Deportes;2005-03-27",
    "Breogán Lugo;Gran Canaria;74;93;Pazo Provincial Dos Deportes;2004-11-27",
    "Breogán Lugo;Lagun Aro Bilbao Basket;89;79;Pazo Provincial Dos Deportes;2005-01-22",
    "Breogán Lugo;Pamesa Valencia;96;88;Pazo Provincial Dos Deportes;2005-02-05",
    "Breogán Lugo;Plus Pujol Lleida;72;80;Pazo Provincial Dos Deportes;2004-10-16",
    "Breogán Lugo;Real Madrid;77;83;Pazo Provincial Dos Deportes;2005-03-13",
    "Breogán Lugo;Ricoh Manresa;96;89;Pazo Provincial Dos Deportes;2005-01-15",
    "Breogán Lugo;Tau Cerámica;48;88;Pazo Provincial Dos Deportes;2005-04-10",
    "Breogán Lugo;Unelco Tenerife;96;72;Pazo Provincial Dos Deportes;2004-11-06",
    "Breogán Lugo;Unicaja;93;82;Pazo Provincial Dos Deportes;2004-12-19",
    "Breogán Lugo;Winterthur F.C. Barcelona;95;85;Pazo Provincial Dos Deportes;2005-02-26",
    "C.B. Granada;7up Joventut;80;93;Palacio Municipal De Deportes;2005-04-09",
    "C.B. Granada;Adecco Estudiantes;74;90;Palacio Municipal De Deportes;2005-04-20",
    "C.B. Granada;Breogán Lugo;95;86;Palacio Municipal De Deportes;2005-01-08",
    "C.B. Granada;Caja San Fernando;88;107;Palacio Municipal De Deportes;2004-12-18",
    "C.B. Granada;Casademont Girona;105;96;Palacio Municipal De Deportes;2004-10-07",
    "C.B. Granada;Etosa Alicante;85;97;Palacio Municipal De Deportes;2005-02-26",
    "C.B. Granada;Forum Valladolid;77;70;Palacio Municipal De Deportes;2004-11-27",
    "C.B. Granada;Gran Canaria;74;88;Palacio Municipal De Deportes;2004-11-06",
    "C.B. Granada;Lagun Aro Bilbao Basket;78;77;Palacio Municipal De Deportes;2004-10-17",
    "C.B. Granada;Pamesa Valencia;81;86;Palacio Municipal De Deportes;2004-10-28",
    "C.B. Granada;Plus Pujol Lleida;81;91;Palacio Municipal De Deportes;2005-04-24",
    "C.B. Granada;Real Madrid;62;81;Palacio Municipal De Deportes;2005-02-06",
    "C.B. Granada;Ricoh Manresa;89;86;Palacio Municipal De Deportes;2005-03-12",
    "C.B. Granada;Tau Cerámica;84;88;Palacio Municipal De Deportes;2004-12-11",
    "C.B. Granada;Unelco Tenerife;99;72;Palacio Municipal De Deportes;2005-03-27",
    "C.B. Granada;Unicaja;65;81;Palacio Municipal De Deportes;2005-05-11",
    "C.B. Granada;Winterthur F.C. Barcelona;72;81;Palacio Municipal De Deportes;2005-01-23",
    "Caja San Fernando;7up Joventut;72;71;Palacio Municipal Deportes San Pablo;2005-04-30",
    "Caja San Fernando;Adecco Estudiantes;81;87;Palacio Municipal Deportes San Pablo;2004-12-29",
    "Caja San Fernando;Breogán Lugo;81;83;Palacio Municipal Deportes San Pablo;2005-02-12",
    "Caja San Fernando;C.B. Granada;69;77;Palacio Municipal Deportes San Pablo;2005-05-15",
    "Caja San Fernando;Casademont Girona;93;87;Palacio Municipal Deportes San Pablo;2005-02-05",
    "Caja San Fernando;Etosa Alicante;81;109;Palacio Municipal Deportes San Pablo;2004-10-17",
    "Caja San Fernando;Forum Valladolid;92;83;Palacio Municipal Deportes San Pablo;2004-12-11",
    "Caja San Fernando;Gran Canaria;93;77;Palacio Municipal Deportes San Pablo;2005-04-20",
    "Caja San Fernando;Lagun Aro Bilbao Basket;95;94;Palacio Municipal Deportes San Pablo;2005-03-12",
    "Caja San Fernando;Pamesa Valencia;81;71;Palacio Municipal Deportes San Pablo;2004-11-06",
    "Caja San Fernando;Plus Pujol Lleida;62;87;Palacio Municipal Deportes San Pablo;2005-01-22",
    "Caja San Fernando;Real Madrid;84;88;Palacio Municipal Deportes San Pablo;2005-04-10",
    "Caja San Fernando;Ricoh Manresa;87;76;Palacio Municipal Deportes San Pablo;2005-03-27",
    "Caja San Fernando;Tau Cerámica;79;87;Palacio Municipal Deportes San Pablo;2005-01-15",
    "Caja San Fernando;Unelco Tenerife;97;56;Palacio Municipal Deportes San Pablo;2004-11-27",
    "Caja San Fernando;Unicaja;67;73;Palacio Municipal Deportes San Pablo;2004-10-03",
    "Caja San Fernando;Winterthur F.C. Barcelona;71;75;Palacio Municipal Deportes San Pablo;2004-10-28",
    "Casademont Girona;7up Joventut;74;78;Palau Girona-Fontajau;2004-10-09",
    "Casademont Girona;Adecco Estudiantes;80;77;Palau Girona-Fontajau;2005-01-16",
    "Casademont Girona;Breogán Lugo;92;99;Palau Girona-Fontajau;2004-12-29",
    "Casademont Girona;C.B. Granada;87;78;Palau Girona-Fontajau;2005-02-13",
    "Casademont Girona;Caja San Fernando;100;82;Palau Girona-Fontajau;2004-10-24",
    "Casademont Girona;Etosa Alicante;86;74;Palau Girona-Fontajau;2005-03-13",
    "Casademont Girona;Forum Valladolid;77;83;Palau Girona-Fontajau;2004-10-03",
    "Casademont Girona;Gran Canaria;83;88;Palau Girona-Fontajau;2005-05-15",
    "Casademont Girona;Lagun Aro Bilbao Basket;109;107;Palau Girona-Fontajau;2004-11-07",
    "Casademont Girona;Pamesa Valencia;85;102;Palau Girona-Fontajau;2004-12-12",
    "Casademont Girona;Plus Pujol Lleida;79;69;Palau Girona-Fontajau;2005-01-30",
    "Casademont Girona;Real Madrid;93;90;Palau Girona-Fontajau;2004-11-28",
    "Casademont Girona;Ricoh Manresa;89;93;Palau Girona-Fontajau;2005-04-21",
    "Casademont Girona;Tau Cerámica;86;94;Palau Girona-Fontajau;2005-04-30",
    "Casademont Girona;Unelco Tenerife;81;80;Palau Girona-Fontajau;2005-04-09",
    "Casademont Girona;Unicaja;70;89;Palau Girona-Fontajau;2005-03-06",
    "Casademont Girona;Winterthur F.C. Barcelona;68;81;Palau Girona-Fontajau;2005-03-27",
    "Etosa Alicante;7up Joventut;83;87;Centro De Tecnificacion De Alicante;2005-01-16",
    "Etosa Alicante;Adecco Estudiantes;99;64;Centro De Tecnificacion De Alicante;2005-02-13",
    "Etosa Alicante;Breogán Lugo;83;78;Centro De Tecnificacion De Alicante;2005-01-30",
    "Etosa Alicante;C.B. Granada;76;67;Centro De Tecnificacion De Alicante;2004-10-03",
    "Etosa Alicante;Caja San Fernando;93;88;Centro De Tecnificacion De Alicante;2005-03-06",
    "Etosa Alicante;Casademont Girona;84;75;Centro De Tecnificacion De Alicante;2004-10-31",
    "Etosa Alicante;Forum Valladolid;80;81;Centro De Tecnificacion De Alicante;2004-12-29",
    "Etosa Alicante;Gran Canaria;73;80;Centro De Tecnificacion De Alicante;2005-05-01",
    "Etosa Alicante;Lagun Aro Bilbao Basket;69;79;Centro De Tecnificacion De Alicante;2005-03-28",
    "Etosa Alicante;Pamesa Valencia;85;78;Centro De Tecnificacion De Alicante;2004-11-28",
    "Etosa Alicante;Plus Pujol Lleida;90;83;Centro De Tecnificacion De Alicante;2004-10-24",
    "Etosa Alicante;Real Madrid;84;74;Centro De Tecnificacion De Alicante;2005-04-21",
    "Etosa Alicante;Ricoh Manresa;91;72;Centro De Tecnificacion De Alicante;2005-04-10",
    "Etosa Alicante;Tau Cerámica;93;97;Centro De Tecnificacion De Alicante;2005-05-15",
    "Etosa Alicante;Unelco Tenerife;81;60;Centro De Tecnificacion De Alicante;2004-12-12",
    "Etosa Alicante;Unicaja;56;60;Centro De Tecnificacion De Alicante;2005-05-29",
    "Etosa Alicante;Unicaja;66;64;Centro De Tecnificacion De Alicante;2004-10-10",
    "Etosa Alicante;Unicaja;94;75;Centro De Tecnificacion De Alicante;2005-05-22",
    "Etosa Alicante;Winterthur F.C. Barcelona;86;80;Centro De Tecnificacion De Alicante;2004-11-07",
    "Forum Valladolid;7up Joventut;86;85;Pabellon Polideportivo Pisuerga;2005-03-19",
    "Forum Valladolid;Adecco Estudiantes;92;95;Pabellon Polideportivo Pisuerga;2004-12-04",
    "Forum Valladolid;Breogán Lugo;81;73;Pabellon Polideportivo Pisuerga;2004-11-13",
    "Forum Valladolid;C.B. Granada;96;87;Pabellon Polideportivo Pisuerga;2005-04-02",
    "Forum Valladolid;Caja San Fernando;107;106;Pabellon Polideportivo Pisuerga;2005-04-16",
    "Forum Valladolid;Casademont Girona;92;81;Pabellon Polideportivo Pisuerga;2005-02-26",
    "Forum Valladolid;Etosa Alicante;71;67;Pabellon Polideportivo Pisuerga;2005-05-11",
    "Forum Valladolid;Gran Canaria;64;79;Pabellon Polideportivo Pisuerga;2004-10-28",
    "Forum Valladolid;Lagun Aro Bilbao Basket;78;84;Pabellon Polideportivo Pisuerga;2004-12-18",
    "Forum Valladolid;Pamesa Valencia;74;85;Pabellon Polideportivo Pisuerga;2005-01-08",
    "Forum Valladolid;Plus Pujol Lleida;82;80;Pabellon Polideportivo Pisuerga;2004-11-20",
    "Forum Valladolid;Real Madrid;72;82;Pabellon Polideportivo Pisuerga;2005-01-22",
    "Forum Valladolid;Ricoh Manresa;91;84;Pabellon Polideportivo Pisuerga;2004-10-16",
    "Forum Valladolid;Tau Cerámica;96;87;Pabellon Polideportivo Pisuerga;2004-10-30",
    "Forum Valladolid;Unelco Tenerife;65;73;Pabellon Polideportivo Pisuerga;2005-02-05",
    "Forum Valladolid;Unicaja;81;78;Pabellon Polideportivo Pisuerga;2005-04-24",
    "Forum Valladolid;Winterthur F.C. Barcelona;73;80;Pabellon Polideportivo Pisuerga;2004-10-07",
    "Gran Canaria;7up Joventut;68;67;Centro Insular De Deportes;2004-10-31",
    "Gran Canaria;Adecco Estudiantes;75;76;Centro Insular De Deportes;2004-11-14",
    "Gran Canaria;Breogán Lugo;88;79;Centro Insular De Deportes;2005-04-02",
    "Gran Canaria;C.B. Granada;62;73;Centro Insular De Deportes;2005-03-20",
    "Gran Canaria;Caja San Fernando;77;61;Centro Insular De Deportes;2004-11-21",
    "Gran Canaria;Casademont Girona;82;75;Centro Insular De Deportes;2004-12-19",
    "Gran Canaria;Etosa Alicante;65;74;Centro Insular De Deportes;2005-01-09",
    "Gran Canaria;Forum Valladolid;82;66;Centro Insular De Deportes;2005-01-29",
    "Gran Canaria;Lagun Aro Bilbao Basket;83;58;Centro Insular De Deportes;2005-04-24",
    "Gran Canaria;Pamesa Valencia;85;70;Centro Insular De Deportes;2005-02-27",
    "Gran Canaria;Plus Pujol Lleida;79;59;Centro Insular De Deportes;2005-04-16",
    "Gran Canaria;Real Madrid;54;79;Centro Insular De Deportes;2004-10-17",
    "Gran Canaria;Ricoh Manresa;73;68;Centro Insular De Deportes;2004-10-07",
    "Gran Canaria;Tau Cerámica;72;64;Centro Insular De Deportes;2005-05-22",
    "Gran Canaria;Tau Cerámica;66;68;Centro Insular De Deportes;2005-05-29",
    "Gran Canaria;Tau Cerámica;64;67;Centro Insular De Deportes;2004-10-23",
    "Gran Canaria;Unelco Tenerife;60;50;Centro Insular De Deportes;2005-01-23",
    "Gran Canaria;Unicaja;70;57;Centro Insular De Deportes;2004-12-05",
    "Gran Canaria;Winterthur F.C. Barcelona;68;80;Centro Insular De Deportes;2005-05-11",
    "Lagun Aro Bilbao Basket;7up Joventut;75;83;Pab. Mun. Dep. La Casilla;2005-02-13",
    "Lagun Aro Bilbao Basket;Adecco Estudiantes;86;84;Pab. Mun. Dep. La Casilla;2004-10-24",
    "Lagun Aro Bilbao Basket;Breogán Lugo;76;82;Pab. Mun. Dep. La Casilla;2004-10-10",
    "Lagun Aro Bilbao Basket;C.B. Granada;85;66;Pab. Mun. Dep. La Casilla;2005-03-05",
    "Lagun Aro Bilbao Basket;Caja San Fernando;72;82;Pab. Mun. Dep. La Casilla;2004-10-31",
    "Lagun Aro Bilbao Basket;Casademont Girona;78;56;Pab. Mun. Dep. La Casilla;2005-03-20",
    "Lagun Aro Bilbao Basket;Etosa Alicante;74;88;Pab. Mun. Dep. La Casilla;2004-11-14",
    "Lagun Aro Bilbao Basket;Forum Valladolid;79;89;Pab. Mun. Dep. La Casilla;2005-05-15",
    "Lagun Aro Bilbao Basket;Gran Canaria;65;86;Pab. Mun. Dep. La Casilla;2005-01-15",
    "Lagun Aro Bilbao Basket;Pamesa Valencia;78;69;Pab. Mun. Dep. La Casilla;2005-04-20",
    "Lagun Aro Bilbao Basket;Plus Pujol Lleida;85;81;Pab. Mun. Dep. La Casilla;2004-12-04",
    "Lagun Aro Bilbao Basket;Real Madrid;55;66;Pab. Mun. Dep. La Casilla;2005-05-01",
    "Lagun Aro Bilbao Basket;Ricoh Manresa;82;65;Pab. Mun. Dep. La Casilla;2004-12-12",
    "Lagun Aro Bilbao Basket;Tau Cerámica;57;104;Pab. Mun. Dep. La Casilla;2004-10-03",
    "Lagun Aro Bilbao Basket;Unelco Tenerife;80;68;Pab. Mun. Dep. La Casilla;2004-12-29",
    "Lagun Aro Bilbao Basket;Unicaja;66;75;Pab. Mun. Dep. La Casilla;2005-01-29",
    "Lagun Aro Bilbao Basket;Winterthur F.C. Barcelona;71;75;Pab. Mun. Dep. La Casilla;2005-04-03",
    "Pamesa Valencia;7up Joventut;83;86;Pabellon Municipal Fuente San Luis;2005-03-06",
    "Pamesa Valencia;Adecco Estudiantes;64;101;Pabellon Municipal Fuente San Luis;2004-10-10",
    "Pamesa Valencia;Breogán Lugo;91;72;Pabellon Municipal Fuente San Luis;2004-10-23",
    "Pamesa Valencia;C.B. Granada;95;71;Pabellon Municipal Fuente San Luis;2005-01-29",
    "Pamesa Valencia;Caja San Fernando;84;78;Pabellon Municipal Fuente San Luis;2005-03-19",
    "Pamesa Valencia;Casademont Girona;85;94;Pabellon Municipal Fuente San Luis;2005-04-17",
    "Pamesa Valencia;Etosa Alicante;90;95;Pabellon Municipal Fuente San Luis;2005-04-03",
    "Pamesa Valencia;Forum Valladolid;91;83;Pabellon Municipal Fuente San Luis;2005-04-30",
    "Pamesa Valencia;Gran Canaria;92;88;Pabellon Municipal Fuente San Luis;2004-10-03",
    "Pamesa Valencia;Lagun Aro Bilbao Basket;97;99;Pabellon Municipal Fuente San Luis;2004-11-20",
    "Pamesa Valencia;Plus Pujol Lleida;94;80;Pabellon Municipal Fuente San Luis;2004-11-14",
    "Pamesa Valencia;Real Madrid;94;77;Pabellon Municipal Fuente San Luis;2005-01-16",
    "Pamesa Valencia;Ricoh Manresa;82;78;Pabellon Municipal Fuente San Luis;2004-12-29",
    "Pamesa Valencia;Tau Cerámica;89;96;Pabellon Municipal Fuente San Luis;2005-02-13",
    "Pamesa Valencia;Unelco Tenerife;104;79;Pabellon Municipal Fuente San Luis;2005-05-15",
    "Pamesa Valencia;Unicaja;82;91;Pabellon Municipal Fuente San Luis;2004-10-31",
    "Pamesa Valencia;Winterthur F.C. Barcelona;71;70;Pabellon Municipal Fuente San Luis;2004-12-05",
    "Plus Pujol Lleida;7up Joventut;95;97;Barris Nord;2004-10-02",
    "Plus Pujol Lleida;Adecco Estudiantes;103;112;Barris Nord;2005-05-15",
    "Plus Pujol Lleida;Breogán Lugo;78;88;Barris Nord;2005-03-05",
    "Plus Pujol Lleida;C.B. Granada;89;96;Barris Nord;2005-01-15",
    "Plus Pujol Lleida;Caja San Fernando;81;88;Barris Nord;2004-10-09",
    "Plus Pujol Lleida;Casademont Girona;69;79;Barris Nord;2004-10-28",
    "Plus Pujol Lleida;Etosa Alicante;77;101;Barris Nord;2005-02-05",
    "Plus Pujol Lleida;Forum Valladolid;92;83;Barris Nord;2005-04-20",
    "Plus Pujol Lleida;Gran Canaria;78;86;Barris Nord;2004-12-11",
    "Plus Pujol Lleida;Lagun Aro Bilbao Basket;85;79;Barris Nord;2005-04-10",
    "Plus Pujol Lleida;Pamesa Valencia;87;86;Barris Nord;2005-03-26",
    "Plus Pujol Lleida;Real Madrid;54;85;Barris Nord;2004-11-07",
    "Plus Pujol Lleida;Ricoh Manresa;89;82;Barris Nord;2004-11-27",
    "Plus Pujol Lleida;Tau Cerámica;66;82;Barris Nord;2004-12-28",
    "Plus Pujol Lleida;Unelco Tenerife;69;80;Barris Nord;2005-04-30",
    "Plus Pujol Lleida;Unicaja;74;79;Barris Nord;2005-02-12",
    "Plus Pujol Lleida;Winterthur F.C. Barcelona;76;88;Barris Nord;2005-03-13",
    "Real Madrid;7up Joventut;74;71;Palacio Vistalegre;2005-05-20",
    "Real Madrid;7up Joventut;90;70;Palacio Vistalegre;2005-05-27",
    "Real Madrid;7up Joventut;80;72;Palacio Vistalegre;2004-12-29",
    "Real Madrid;Adecco Estudiantes;81;64;Palacio Vistalegre;2005-06-03",
    "Real Madrid;Adecco Estudiantes;77;68;Palacio Vistalegre;2004-10-03",
    "Real Madrid;Adecco Estudiantes;67;89;Palacio Vistalegre;2005-06-05",
    "Real Madrid;Breogán Lugo;78;76;Palacio Vistalegre;2004-10-31",
    "Real Madrid;C.B. Granada;92;73;Palacio Vistalegre;2004-10-24",
    "Real Madrid;Caja San Fernando;63;66;Palacio Vistalegre;2004-12-05",
    "Real Madrid;Casademont Girona;78;67;Palacio Vistalegre;2005-04-03",
    "Real Madrid;Etosa Alicante;81;61;Palacio Vistalegre;2004-11-21",
    "Real Madrid;Forum Valladolid;86;62;Palacio Vistalegre;2004-10-10",
    "Real Madrid;Gran Canaria;77;66;Palacio Vistalegre;2005-03-06",
    "Real Madrid;Lagun Aro Bilbao Basket;93;51;Palacio Vistalegre;2005-01-10",
    "Real Madrid;Pamesa Valencia;87;76;Palacio Vistalegre;2005-04-24",
    "Real Madrid;Plus Pujol Lleida;83;65;Palacio Vistalegre;2005-03-20",
    "Real Madrid;Ricoh Manresa;80;65;Palacio Vistalegre;2005-05-15",
    "Real Madrid;Tau Cerámica;69;74;Palacio Vistalegre;2005-01-30",
    "Real Madrid;Tau Cerámica;88;82;Palacio Vistalegre;2005-06-24",
    "Real Madrid;Tau Cerámica;82;83;Palacio Vistalegre;2005-06-22",
    "Real Madrid;Unelco Tenerife;81;72;Palacio Vistalegre;2005-02-13",
    "Real Madrid;Unicaja;79;71;Palacio Vistalegre;2004-11-14",
    "Real Madrid;Winterthur F.C. Barcelona;74;81;Palacio Vistalegre;2005-04-17",
    "Ricoh Manresa;7up Joventut;79;69;Pavello Nou Congost;2004-10-24",
    "Ricoh Manresa;Adecco Estudiantes;88;97;Pavello Nou Congost;2005-01-30",
    "Ricoh Manresa;Breogán Lugo;77;71;Pavello Nou Congost;2005-04-24",
    "Ricoh Manresa;C.B. Granada;88;75;Pavello Nou Congost;2004-10-31",
    "Ricoh Manresa;Caja San Fernando;87;56;Pavello Nou Congost;2004-11-14",
    "Ricoh Manresa;Casademont Girona;97;82;Pavello Nou Congost;2004-11-21",
    "Ricoh Manresa;Etosa Alicante;69;77;Pavello Nou Congost;2004-12-05",
    "Ricoh Manresa;Forum Valladolid;76;72;Pavello Nou Congost;2005-03-06",
    "Ricoh Manresa;Gran Canaria;76;71;Pavello Nou Congost;2005-02-13",
    "Ricoh Manresa;Lagun Aro Bilbao Basket;100;77;Pavello Nou Congost;2005-04-17",
    "Ricoh Manresa;Pamesa Valencia;75;92;Pavello Nou Congost;2005-05-12",
    "Ricoh Manresa;Plus Pujol Lleida;80;70;Pavello Nou Congost;2005-04-03",
    "Ricoh Manresa;Real Madrid;83;85;Pavello Nou Congost;2004-12-19",
    "Ricoh Manresa;Tau Cerámica;72;90;Pavello Nou Congost;2004-10-10",
    "Ricoh Manresa;Unelco Tenerife;86;71;Pavello Nou Congost;2004-10-03",
    "Ricoh Manresa;Unicaja;66;78;Pavello Nou Congost;2005-03-20",
    "Ricoh Manresa;Winterthur F.C. Barcelona;91;75;Pavello Nou Congost;2005-01-09",
    "Tau Cerámica;7up Joventut;86;74;Fernando Buesa Arena;2004-11-13",
    "Tau Cerámica;Adecco Estudiantes;98;88;Fernando Buesa Arena;2005-03-20",
    "Tau Cerámica;Breogán Lugo;108;89;Fernando Buesa Arena;2004-12-04",
    "Tau Cerámica;C.B. Granada;109;66;Fernando Buesa Arena;2005-04-16",
    "Tau Cerámica;Caja San Fernando;101;93;Fernando Buesa Arena;2005-04-23",
    "Tau Cerámica;Casademont Girona;103;83;Fernando Buesa Arena;2005-01-08",
    "Tau Cerámica;Etosa Alicante;97;82;Fernando Buesa Arena;2004-12-19",
    "Tau Cerámica;Forum Valladolid;104;58;Fernando Buesa Arena;2005-03-12",
    "Tau Cerámica;Gran Canaria;77;55;Fernando Buesa Arena;2005-02-06",
    "Tau Cerámica;Gran Canaria;90;61;Fernando Buesa Arena;2005-05-19",
    "Tau Cerámica;Gran Canaria;75;64;Fernando Buesa Arena;2005-05-26",
    "Tau Cerámica;Lagun Aro Bilbao Basket;92;90;Fernando Buesa Arena;2005-02-26",
    "Tau Cerámica;Pamesa Valencia;103;100;Fernando Buesa Arena;2004-10-06",
    "Tau Cerámica;Plus Pujol Lleida;120;80;Fernando Buesa Arena;2005-05-12",
    "Tau Cerámica;Real Madrid;74;68;Fernando Buesa Arena;2005-06-19",
    "Tau Cerámica;Real Madrid;69;70;Fernando Buesa Arena;2005-06-26",
    "Tau Cerámica;Real Madrid;82;84;Fernando Buesa Arena;2005-06-17",
    "Tau Cerámica;Real Madrid;92;106;Fernando Buesa Arena;2004-10-27",
    "Tau Cerámica;Ricoh Manresa;90;67;Fernando Buesa Arena;2005-01-22",
    "Tau Cerámica;Unelco Tenerife;78;67;Fernando Buesa Arena;2004-10-16",
    "Tau Cerámica;Unicaja;72;63;Fernando Buesa Arena;2005-06-02",
    "Tau Cerámica;Unicaja;71;78;Fernando Buesa Arena;2005-04-02",
    "Tau Cerámica;Unicaja;64;53;Fernando Buesa Arena;2005-06-04",
    "Tau Cerámica;Winterthur F.C. Barcelona;72;79;Fernando Buesa Arena;2004-11-21",
    "Unelco Tenerife;7up Joventut;70;83;Pabellon Insular Santiago Martin;2005-01-29",
    "Unelco Tenerife;Adecco Estudiantes;93;83;Pabellon Insular Santiago Martin;2004-10-31",
    "Unelco Tenerife;Breogán Lugo;80;71;Pabellon Insular Santiago Martin;2005-03-21",
    "Unelco Tenerife;C.B. Granada;58;61;Pabellon Insular Santiago Martin;2004-11-13",
    "Unelco Tenerife;Caja San Fernando;82;69;Pabellon Insular Santiago Martin;2005-04-03",
    "Unelco Tenerife;Casademont Girona;95;77;Pabellon Insular Santiago Martin;2004-12-04",
    "Unelco Tenerife;Etosa Alicante;76;90;Pabellon Insular Santiago Martin;2005-04-16",
    "Unelco Tenerife;Forum Valladolid;78;75;Pabellon Insular Santiago Martin;2004-10-23",
    "Unelco Tenerife;Gran Canaria;63;93;Pabellon Insular Santiago Martin;2004-10-10",
    "Unelco Tenerife;Lagun Aro Bilbao Basket;67;77;Pabellon Insular Santiago Martin;2005-05-11",
    "Unelco Tenerife;Pamesa Valencia;59;78;Pabellon Insular Santiago Martin;2004-12-19",
    "Unelco Tenerife;Plus Pujol Lleida;86;71;Pabellon Insular Santiago Martin;2005-01-09",
    "Unelco Tenerife;Real Madrid;68;76;Pabellon Insular Santiago Martin;2004-10-07",
    "Unelco Tenerife;Ricoh Manresa;83;63;Pabellon Insular Santiago Martin;2005-02-26",
    "Unelco Tenerife;Tau Cerámica;87;93;Pabellon Insular Santiago Martin;2005-03-06",
    "Unelco Tenerife;Unicaja;72;99;Pabellon Insular Santiago Martin;2004-11-21",
    "Unelco Tenerife;Winterthur F.C. Barcelona;65;91;Pabellon Insular Santiago Martin;2005-04-24",
    "Unicaja;7up Joventut;82;72;Pal. De Deportes Jose Ma Martin Carpena;2004-12-11",
    "Unicaja;Adecco Estudiantes;69;81;Pal. De Deportes Jose Ma Martin Carpena;2005-05-01",
    "Unicaja;Breogán Lugo;77;64;Pal. De Deportes Jose Ma Martin Carpena;2005-05-15",
    "Unicaja;C.B. Granada;101;68;Pal. De Deportes Jose Ma Martin Carpena;2004-12-28",
    "Unicaja;Caja San Fernando;90;77;Pal. De Deportes Jose Ma Martin Carpena;2005-02-26",
    "Unicaja;Casademont Girona;79;87;Pal. De Deportes Jose Ma Martin Carpena;2004-10-16",
    "Unicaja;Etosa Alicante;60;65;Pal. De Deportes Jose Ma Martin Carpena;2005-05-19",
    "Unicaja;Etosa Alicante;73;64;Pal. De Deportes Jose Ma Martin Carpena;2005-01-23",
    "Unicaja;Etosa Alicante;81;74;Pal. De Deportes Jose Ma Martin Carpena;2005-05-26",
    "Unicaja;Etosa Alicante;71;69;Pal. De Deportes Jose Ma Martin Carpena;2005-05-31",
    "Unicaja;Forum Valladolid;75;64;Pal. De Deportes Jose Ma Martin Carpena;2005-01-16",
    "Unicaja;Gran Canaria;83;59;Pal. De Deportes Jose Ma Martin Carpena;2005-04-10",
    "Unicaja;Lagun Aro Bilbao Basket;86;69;Pal. De Deportes Jose Ma Martin Carpena;2004-10-27",
    "Unicaja;Pamesa Valencia;102;85;Pal. De Deportes Jose Ma Martin Carpena;2005-03-13",
    "Unicaja;Plus Pujol Lleida;80;85;Pal. De Deportes Jose Ma Martin Carpena;2004-10-06",
    "Unicaja;Real Madrid;82;85;Pal. De Deportes Jose Ma Martin Carpena;2005-03-27",
    "Unicaja;Ricoh Manresa;82;70;Pal. De Deportes Jose Ma Martin Carpena;2004-11-06",
    "Unicaja;Tau Cerámica;83;98;Pal. De Deportes Jose Ma Martin Carpena;2004-11-27",
    "Unicaja;Tau Cerámica;95;92;Pal. De Deportes Jose Ma Martin Carpena;2005-06-07",
    "Unicaja;Tau Cerámica;62;74;Pal. De Deportes Jose Ma Martin Carpena;2005-06-09",
    "Unicaja;Unelco Tenerife;86;67;Pal. De Deportes Jose Ma Martin Carpena;2005-04-20",
    "Unicaja;Winterthur F.C. Barcelona;93;65;Pal. De Deportes Jose Ma Martin Carpena;2005-02-06",
    "Winterthur F.C. Barcelona;7up Joventut;91;89;Palau Blaugrana;2005-05-15",
    "Winterthur F.C. Barcelona;Adecco Estudiantes;73;74;Palau Blaugrana;2005-05-19",
    "Winterthur F.C. Barcelona;Adecco Estudiantes;89;81;Palau Blaugrana;2005-03-06",
    "Winterthur F.C. Barcelona;Adecco Estudiantes;83;79;Palau Blaugrana;2005-05-26",
    "Winterthur F.C. Barcelona;Breogán Lugo;96;88;Palau Blaugrana;2004-10-03",
    "Winterthur F.C. Barcelona;C.B. Granada;76;64;Palau Blaugrana;2004-10-10",
    "Winterthur F.C. Barcelona;Caja San Fernando;70;67;Palau Blaugrana;2005-01-30",
    "Winterthur F.C. Barcelona;Casademont Girona;86;84;Palau Blaugrana;2004-11-14",
    "Winterthur F.C. Barcelona;Etosa Alicante;71;73;Palau Blaugrana;2005-03-20",
    "Winterthur F.C. Barcelona;Forum Valladolid;82;65;Palau Blaugrana;2005-02-13",
    "Winterthur F.C. Barcelona;Gran Canaria;74;61;Palau Blaugrana;2004-12-28",
    "Winterthur F.C. Barcelona;Lagun Aro Bilbao Basket;86;78;Palau Blaugrana;2004-11-28",
    "Winterthur F.C. Barcelona;Pamesa Valencia;95;105;Palau Blaugrana;2005-04-10",
    "Winterthur F.C. Barcelona;Plus Pujol Lleida;89;72;Palau Blaugrana;2004-10-31",
    "Winterthur F.C. Barcelona;Real Madrid;64;66;Palau Blaugrana;2004-12-12",
    "Winterthur F.C. Barcelona;Ricoh Manresa;96;57;Palau Blaugrana;2005-05-01",
    "Winterthur F.C. Barcelona;Tau Cerámica;68;82;Palau Blaugrana;2005-04-20",
    "Winterthur F.C. Barcelona;Unelco Tenerife;77;69;Palau Blaugrana;2005-01-16",
    "Winterthur F.C. Barcelona;Unicaja;87;85;Palau Blaugrana;2004-10-24"
]

interface eredmenyekAdat {
    hazai: string
    idegen: string
    hazai_pont: number
    idegen_pont: number
    helyszin: string
    idopont: string
}

function ObjektumFeltoltes(feltoltendoElem: string[]): eredmenyekAdat[] {
    var beolvasottAdatok: eredmenyekAdat[] = [];
    for (let i: number = 0; i < feltoltendoElem.length; i++) {
        let daraboltAdatok = feltoltendoElem[i].split(";");
        let ujAdatok: eredmenyekAdat = {
            hazai: String(daraboltAdatok[0]),
            idegen: String(daraboltAdatok[1]),
            hazai_pont: Number(daraboltAdatok[2]),
            idegen_pont: Number(daraboltAdatok[3]),
            helyszin: String(daraboltAdatok[4]),
            idopont: String(daraboltAdatok[5])
        }
        beolvasottAdatok.push(ujAdatok);
    }
    return beolvasottAdatok;
}
var eredmenyekAdatok: eredmenyekAdat[] = ObjektumFeltoltes(eredmenyek)
console.log(eredmenyekAdatok)

function RealMadridHazai(vizsgaltTomb: eredmenyekAdat[]): number {
    let hazaiMerkozes: number = 0
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].hazai == "Real Madrid") {
            hazaiMerkozes++
        }
    }
    return hazaiMerkozes
}
function RealMadridIdegen(vizsgaltTomb: eredmenyekAdat[]): number {
    let idegenMerkozes: number = 0
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].idegen == "Real Madrid") {
            idegenMerkozes++
        }
    }
    return idegenMerkozes
}
function eredmenyKiir(RealMadridHazai, RealMadridIdegen) {
    document.write(`3.feladat: Real Madrid: Hazai: ${RealMadridHazai}, Idegen: ${RealMadridIdegen}`)
}
eredmenyKiir(RealMadridHazai(eredmenyekAdatok), RealMadridIdegen(eredmenyekAdatok))

function VoltEDontetlen(vizsgaltTomb: eredmenyekAdat[]): string {
    let voltEDontetlen = "nem"
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].idegen == vizsgaltTomb[i].hazai) {
            voltEDontetlen = "igen"
        }
    }
    return voltEDontetlen
}
function VoltEDontetlenKiir(VoltEDontetlen) {
    document.write(`<br> 4.feladat: Volt dontetlen? ${VoltEDontetlen}`)
}
VoltEDontetlenKiir(VoltEDontetlen(eredmenyekAdatok))

function miApontosNev(vizsgaltTomb: eredmenyekAdat[]): string {
    let csapat: string = ""
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].hazai.indexOf("Barcelona") != -1) {
            csapat = vizsgaltTomb[i].hazai
        }
    }
    return csapat
}
function miApontosNevKiir(miApontosNev) {
    document.write(` <br> 5.feladat: barcelonai csapat neve: ${miApontosNev}`)
}
miApontosNevKiir(miApontosNev(eredmenyekAdatok))

document.write(` <br> 6.feladat`)
function melyCsapatokJatszottak(vizsgaltTomb: eredmenyekAdat[]): void {
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i].idopont == "2004-11-21") {
            document.write(`<br>${vizsgaltTomb[i].hazai} ${vizsgaltTomb[i].idegen} (${vizsgaltTomb[i].hazai_pont},${vizsgaltTomb[i].idegen_pont})`)
        }
    }
}
melyCsapatokJatszottak(eredmenyekAdatok)

document.write(` <br> 7.feladat`)
function stadionValogato(vizsgaltTomb: eredmenyekAdat[]): void {
    let stadionok: string[] = []
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        const stadionNev: string = vizsgaltTomb[i].helyszin
        if (!stadionok.includes(stadionNev)) {
            stadionok.push(stadionNev)
            const hanyszorSzerepel = stadionMegszamlalo(vizsgaltTomb, stadionNev)
            if (hanyszorSzerepel > 20) {
                document.write(`<br>${stadionNev}: ${hanyszorSzerepel}`)
            }
        }
    }
}
stadionValogato(eredmenyekAdatok)

function stadionMegszamlalo(vizsgaltTomb: eredmenyekAdat[], stadionNev: string): number {
    let hanyszorSzerepel: number = 0
    for (let j: number = 0; j < vizsgaltTomb.length; j++) {
        if (vizsgaltTomb[j].helyszin === stadionNev) {
            hanyszorSzerepel++
        }
    }
    return hanyszorSzerepel
}
