/* Készíts egy olyan kódot, mely paraméterként bekér egy számot és egy osztót és kiírjaszövegesen,hogy az adott osztó, osztja-e az egész számot, úgy, hogy a maradék nulla. */

let szam = Number(prompt("Adj megy egy szamot"));
let oszto = Number(prompt("Adj meg egy osztot!"));
let oszthato = szam%oszto==0;

if (oszthato) {
document.write("A szam oszthato")
}

else {
document.write("A szam nem oszthato")
}

