/*Készíts egy programot, ami egy adott intervallumban generál ki páros számot, és írjaki az értékét, a határétéket te magad állíthatod be,bekérés,alapján.*/

let alsoHatar = Number(prompt("Add meg az also hatart!"));
let felsoHatar = Number(prompt("Add meg a felso hatart!"));
let szam = Math.round(Math.random()*(felsoHatar - alsoHatar))+alsoHatar;
if(szam%2==0){
document.write("A szam = " +szam)
}

else if (szam==felsoHatar){
szam=szam-1
document.write("A szam = " +szam)
}

else {
szam=szam+1
document.write("A szam = " +szam)
}
