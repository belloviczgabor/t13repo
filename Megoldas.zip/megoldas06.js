/* Készíts egy programot,ami kiírja az első 10 négyzetszámot! */

for (let i=1; i<=10; i++) {
    document.write(i*i+',')
}
