/*Készíts egy olyan kódot mely kiírja az adott file készítőjének •Nevét•Csoportjának azonosítóját (melyik #Teamtagja)•3.-4. és 5. sorpedig az legyen, mennyire érti a HTML, CSS és jelenlegi JavaScript tananyagokat1-100-ig(pl.: html:90)*/
    
document.write("Bellovicz Gabor <hr>"); 
document.write("#Team13 <hr>");
document.write("HTML: 90 <hr>");
document.write("CSS: 85 <hr>");
document.write("JavaScript: 65 <hr>");


