/*Készíts egy olyan programot, mely bekér egy számot és a hatványozás mértékét, éskiírjaannak hatványát.pl.: 2 és 3,azazkettő a harmadikon,azaz az eredmény 8 lesz!*/

let hatvanyAlap = Number(prompt("Adj meg egy szamot!"));
let hatvanyKitevo = Number(prompt("Add meg a hatvanyt!"));
document.write(Math.pow(hatvanyAlap,hatvanyKitevo))