/*Készíts egy programot, ami bekér egy életkort 1-120között és ennek függvényében megjeleníti az illető besorolását. 120 kor felettvagy 0 alatt, pedig hibát kapjunk!•Kisgyermekkor:0-6 év•Gyermekkor: 6-12 év•Serdülőkor: 12-16 év•Ifjúkor: 16-20 év•Fiatal felnőttkor: 20-30 év•Felnőttkor: 30-60•Aggkor: 60-tól*/

let eletkor =Number(prompt("Add meg az eletkort"));

if (eletkor>=0 && eletkor<6){
document.write("Kisgyermekkor")
}

else if (eletkor>=6 && eletkor<12){
document.write("Gyermekkor")
}

else if (eletkor>=12 && eletkor<16){
document.write("Serdulokor")
}

else if (eletkor>=16 && eletkor<20){
document.write("Ifjukor")
}

else if (eletkor>=20 && eletkor<30){
document.write("Fiatal felnott kor")
}

else if (eletkor>=30 && eletkor<60){
document.write("Felnott kor")
}

else if (eletkor>=60 && eletkor<120) {
document.write("Aggkor")
}

else {
document.write("Hibas eletkor")
}